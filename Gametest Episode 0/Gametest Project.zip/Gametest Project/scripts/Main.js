/*System BeforeWatchdogTerminateEvent */
import "./API/bug"